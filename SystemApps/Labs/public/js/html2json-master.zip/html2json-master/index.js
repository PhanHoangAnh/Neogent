module.exports = require('./src/html2json');
