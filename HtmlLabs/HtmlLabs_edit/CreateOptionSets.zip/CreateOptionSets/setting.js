var setting = [
{
    name: "AppManager",
    url: "",
    logo: "/img/logo.png"
},
{
    name: "Create Option Sets",
    url: "OptionSets",
    logo: "OptionSets/img/LogoIcon.png"
}, {
    name: "createProduct",
    url: "createProduct",
    logo: "template/imgs/icon.png"
},
{
    name: "ArtTemplate",
    url: "arttemp",
    logo: "template/imgs/LogoSamples/1.png"
}]



module.exports = setting;
